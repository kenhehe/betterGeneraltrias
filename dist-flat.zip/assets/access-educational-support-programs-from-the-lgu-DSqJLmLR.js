const n=`# Access Educational Support Programs from the LGU — Tagaytay City

Below are **city-led** or **LGU-facilitated** programs you can use for study support: free school supplies, e-library access, student employment (SPES) via PESO, scholarships, and cash/education assistance. Links point to official pages or recent announcements.

---

## 1) Free School Supplies (SEF-funded)

**What it is**

- The City provides **free school supplies** to public school learners using the **Special Education Fund (SEF)**, announced each school year with distribution schedules.

**How to access**

1. Watch your school’s advisory and the **DepEd Tagaytay City** Division memos for **distribution schedules**.
2. Learners (with parent/guardian) claim supplies at the school on the announced date.

**Links**

- DepEd Tagaytay City memo: **Distribution of School Supplies (SEF)** (2025 schedule) — deped.tagaytay.gov.ph
- News: **City to distribute free school supplies** — Tagaytay City Official Sources (June 7, 2025)
- City info posts often echo the distribution dates via DepEd/City channels.

---

## 2) City e-Library (Free Study Space, Wi-Fi, Computers & Printing)

**What it is**

- A **government-run e-Library** offering **free internet, computer use, and printing** for students; open **daily 8:00 a.m.–12:00 midnight** at **Tagaytay City Sports Complex, Brgy. Kaybagal South**.

**How to access**

1. Go to the **Tagaytay City e-Library (Tagaytay City Sports Complex)** during operating hours.
2. Sign the logbook; follow usage limits (to give everyone a turn).

**Links**

- SunStar: **E-Library reopens; open daily 8 a.m.–12 midnight** (July 26, 2025)
- The POST: **City library reopens, free digital access & printing** (July 28, 2025)
- Background: **City launched first gov’t e-Library** (2019) — Official Government Sources

---

## 3) Student Employment (SPES) via PESO Tagaytay City

**What it is**

- The **Special Program for the Employment of Students (SPES)** lets poor but deserving **students/OSYs (15–30)** work during breaks to earn and gain experience.
- Implemented locally through the **Public Employment Service Office (PESO)** with DOLE.

**How to access**

1. Follow **PESO Tagaytay City** on Facebook for **SPES application windows** and job fair advisories.
2. Prepare IDs, school docs, and income/indigency proofs per announcement.
3. Submit online or at the PESO office; attend orientation when shortlisted.

**Links**

- **PESO Tagaytay City** Facebook page (official announcements)
- DepEd/BLSS-YFD: **SPES 2025 guidelines & timelines**
- City press: **PESO career fair / youth employment events** — City Information Office

---

## 4) LGU-linked Scholarships & Incentives

**What it is**

- The City (and Congressional office) **periodically opens scholarship calls** or **educational incentives** for local students, separate from school-based grants.

**How to access**

1. Monitor the **Tagaytay City Government / City Information Office** and the **Office of the Mayor / Congresswoman** for official **calls**.
2. Prepare residency and academic documents; submit by deadline; attend screening/orientation.

**Links (examples & history)**

- News: **Tagaytay City offers college scholarship to poor residents** — The Freeman/Philstar (program history)
- Sample: **Cindi “Skwela” Scholarship** highlights via official pages (video updates)
- Also check school-based options in-city (e.g., **LCIC scholarships**, **UC scholarships**) which can complement LGU aid.

---

## 5) Educational / Cash Assistance (LGU-facilitated with DSWD)

**What it is**

- **Educational assistance pay-outs** (e.g., AICS) are nationally run by DSWD but are often **coordinated locally** with the **City** for venue and beneficiary management.

**How to access**

1. Watch announcements from **DSWD-7** and the **City Information Office** for **Tagaytay City payout schedules**.
2. Bring student ID, enrollment proof, and required forms on your assigned date.

**Links (context)**

- Tagaytay City Official Sources: **Education assistance payout in Tagaytay City** (local coverage)
- Official Government Sources: **DSWD-7 educational assistance** (program overview & amounts)

---

## Quick Directory

- **City Information Office (Tagaytay City)** — city-wide program announcements
- **PESO Tagaytay City** — SPES, job fairs, recruitment & youth work programs
- **DepEd Tagaytay City Division** — school memos (SEF supplies, schedules)
- **Tagaytay City e-Library (Tagaytay City Sports Complex, Kaybagal South)** — free study space & digital access

---

## Tips to Maximize Support

- **Stack benefits** where allowed: e.g., SEF school supplies **+** SPES stipend **+** school-based scholarship.
- Keep a folder with **PSA Birth Cert**, **Barangay Residency**, **School ID**, **Report Cards/COE**, and **2x2 photos** ready.
- Turn on notifications for **PESO** and **City Information** pages so you don’t miss application windows.
`;export{n as default};
