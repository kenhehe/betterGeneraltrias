const e=`# How to Set Up a Business Partnership

## Step 1: Register with SEC

**Prepare documents:**

- Partnership name (check via [SEC eSPARC](https://espac.sec.gov.ph/))
- Notarized Articles of Partnership
- IDs/TINs of partners, office address, capital structure

**File online** through [SEC eSPARC](https://espac.sec.gov.ph/) and pay fees.

**Output:** SEC Certificate of Recording + Approved Business Name

## Step 2: Apply for Business Permit

Go to **Tagaytay City BPLO** (Business Permit and Licensing Office).

**Requirements:**

- Unified Application Form
- SEC Certificate of Registration + Articles of Partnership
- Occupancy Permit (if owner) OR Lease Contract (if renting)
- Community Tax Certificate (CTC)

Apply in person or online via [Tagaytay City Online Business Permit Portal](https://tagaytay.gov.ph/business-permits/).

> Note: Inspections may include zoning, sanitary, and fire safety checks.

## Step 3: Register with BIR

File at the **BIR Revenue District Office (RDO)** where your office is located.

- Fill out [BIR Form 1903](https://www.bir.gov.ph/images/1903%20Jan%202024.pdf)
- Submit SEC Certificate + Articles of Partnership + valid IDs
- Pay registration fee + Documentary Stamp Tax (DST)

**Within 30 days of receiving BIR Certificate:**

- Apply for Authority to Print Receipts (Form 1906) OR enroll in e-invoicing
- Register your Books of Accounts

## Step 4: Register as Employer (if hiring)

Enroll with:

- [SSS](https://www.sss.gov.ph/)
- [PhilHealth](https://www.philhealth.gov.ph/)
- [Pag-IBIG](https://www.pagibigfund.gov.ph/)

## Process Flow

1. SEC name check + register via [SEC eSPARC](https://espac.sec.gov.ph/)
2. Secure Barangay Certification + site/lease documents
3. Apply for Business Permit at [Tagaytay City BPLO](https://tagaytay.gov.ph/business-permits/)
4. File BIR Form 1903 → apply ATP → register books

## Document Checklist

- [ ] SEC Articles of Partnership + SEC Certificate
- [ ] Lease Contract OR Occupancy/Building docs
- [ ] Tagaytay City BPLO Unified Application Form + CTC
- [ ] BIR Form 1903, IDs, ATP/Books

With these steps, your partnership in Tagaytay City will be fully compliant and ready to operate!
`;export{e as default};
